
/**
 * SCORM 1.2 API Wrapper
 */

var API = null;

function initializeSCORM() {
  API = getAPI();
  if (API) {
    API.LMSInitialize("");
    API.LMSSetValue("cmi.core.lesson_status", "incomplete");
    API.LMSCommit("");
  }
}

function getAPI() {
  var theAPI = findAPI(window);
  if (!theAPI && window.opener) {
    theAPI = findAPI(window.opener);
  }
  return theAPI;
}

function findAPI(win) {
  var findAttempts = 0;
  while (win.API == null && win.parent != null && win.parent != win) {
    findAttempts++;
    if (findAttempts > 7) return null;
    win = win.parent;
  }
  return win.API;
}

function setComplete() {
  if (API) {
    API.LMSSetValue("cmi.core.lesson_status", "completed");
    API.LMSCommit("");
  }
}

function setScore(score) {
  if (API) {
    API.LMSSetValue("cmi.core.score.raw", score.toString());
    API.LMSSetValue("cmi.core.score.min", "0");
    API.LMSSetValue("cmi.core.score.max", "100");
    API.LMSCommit("");
  }
}

function exitCourse() {
  if (API) {
    API.LMSFinish("");
  }
  window.close();
}

function saveProgress(location) {
  if (API) {
    API.LMSSetValue("cmi.core.lesson_location", location);
    API.LMSCommit("");
  }
}